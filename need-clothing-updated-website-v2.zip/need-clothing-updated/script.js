const menuBtn=document.querySelector('.menu-btn');
const navLinks=document.querySelector('.nav-links');
menuBtn?.addEventListener('click',()=>navLinks.classList.toggle('open'));
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>navLinks.classList.remove('open')));
const reveals=document.querySelectorAll('.reveal');
const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add('active')})},{threshold:.12});
reveals.forEach(el=>observer.observe(el));
const chips=document.querySelectorAll('.filter-chip');
const cards=document.querySelectorAll('.listing-card');
chips.forEach(chip=>chip.addEventListener('click',()=>{
  chips.forEach(c=>c.classList.remove('active'));
  chip.classList.add('active');
  const filter=chip.dataset.filter;
  cards.forEach(card=>card.classList.toggle('hide',filter!=='all'&&card.dataset.category!==filter));
}));
