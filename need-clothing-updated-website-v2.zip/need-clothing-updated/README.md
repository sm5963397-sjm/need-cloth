# Need Clothing Website

Premium pitch-ready website for Need Clothing.

## How to check
1. Extract ZIP
2. Open `index.html` in Chrome
3. Internet is needed for fonts, Instagram reel embed and placeholder images.

## How to edit
- Replace placeholder product images in `styles.css` `.p1` to `.p6`
- Update product names in `index.html`
- Replace reel link in `data-instgrm-permalink`

## Included
- Flipkart-style product listing
- Product filters
- Instagram reel embed
- Premium text logo
- WhatsApp and Instagram CTAs
- Store policies
- Location button
- Fully responsive design
